.. _statistics:

==========
Statistics
==========

Basic concepts in statistics for machine learning.



.. rubric:: References

.. [1] Example
