.. _applications:

============
Applications
============

.. contents:: :local:


Anomaly Detection
=================

Be the first to `contribute! <https://github.com/bfortuner/ml-cheatsheet>`__



Computer Vision
===============

Classification
--------------

Be the first to `contribute! <https://github.com/bfortuner/ml-cheatsheet>`__

Object Detection
----------------

Be the first to `contribute! <https://github.com/bfortuner/ml-cheatsheet>`__

Segmentation
------------

Be the first to `contribute! <https://github.com/bfortuner/ml-cheatsheet>`__



Natural Language
================

Dialog Systems
--------------

Be the first to `contribute! <https://github.com/bfortuner/ml-cheatsheet>`__

Machine Translation
-------------------

Be the first to `contribute! <https://github.com/bfortuner/ml-cheatsheet>`__

Speech Recognition
------------------

Be the first to `contribute! <https://github.com/bfortuner/ml-cheatsheet>`__

Text Summarization
------------------

Be the first to `contribute! <https://github.com/bfortuner/ml-cheatsheet>`__

Question Answering
------------------

Be the first to `contribute! <https://github.com/bfortuner/ml-cheatsheet>`__



Recommender Systems
===================

Be the first to `contribute! <https://github.com/bfortuner/ml-cheatsheet>`__



Time-Series
===========

Be the first to `contribute! <https://github.com/bfortuner/ml-cheatsheet>`__


.. rubric:: References

.. [1] Example Reference
