.. _contribute:

==========
Contribute
==========

Become a contributor! Check out our `github <http://github.com/bfortuner/ml-cheatsheet/>`_ for more information.
