.. _probability:

================
Training (empty)
================

.. contents:: :local:


Combating Overfitting
=====================

Cross-validation
----------------

Be the first to `contribute! <https://github.com/bfortuner/ml-cheatsheet>`__

Validation Set
--------------

Be the first to `contribute! <https://github.com/bfortuner/ml-cheatsheet>`__

Test Set
--------

Be the first to `contribute! <https://github.com/bfortuner/ml-cheatsheet>`__



Hyperparameter Tuning
=====================

Learning Rate
-------------

Be the first to `contribute! <https://github.com/bfortuner/ml-cheatsheet>`__

Optimizers
----------

Be the first to `contribute! <https://github.com/bfortuner/ml-cheatsheet>`__



Model Evaluation
================


Bias-Variance Tradeoff
----------------------

Be the first to `contribute! <https://github.com/bfortuner/ml-cheatsheet>`__

Loss Functions
--------------

Be the first to `contribute! <https://github.com/bfortuner/ml-cheatsheet>`__

Precision vs Recall
-------------------

Be the first to `contribute! <https://github.com/bfortuner/ml-cheatsheet>`__









.. rubric:: References

.. [1] Example
