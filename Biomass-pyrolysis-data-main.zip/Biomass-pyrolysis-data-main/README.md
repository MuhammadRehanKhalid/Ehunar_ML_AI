# Biomass-pyrolysis-data
This repository contains two files, one is biomass pyrolysis dataset, and the other is biomass pyrolysis dataset with source.
